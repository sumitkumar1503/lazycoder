from django.apps import AppConfig


class MultiplexConfig(AppConfig):
    name = 'multiplex'
